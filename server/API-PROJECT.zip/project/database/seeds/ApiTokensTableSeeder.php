<?php

use Illuminate\Database\Seeder;
use App\ApiToken;

class ApiTokensTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
      $api_token = new ApiToken;
      $api_token->token = 'ijdasoijds09d098';
      $api_token->save();
    }
}
