<?php

use Illuminate\Database\Seeder;
use App\User;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
      $user = new User;
      $user->name = 'Revando';
      $user->username = 'revze';
      $user->email = 'revando@outlook.com';
      $user->password = bcrypt('revze');
      $user->date_birth = '1999-05-19';
      $user->phone_number = '085816865807';
      $user->profile_picture = 'revze.png';
      $user->save();
    }
}
