<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CaptchaController extends Controller
{
    public function generateCaptcha()
    {
      $response = [];

      $alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
      $number = '123456789';
      $rand_alphabet = substr(str_shuffle($alphabet), 0, 5);
      $rand_number = substr(str_shuffle($number), 0, 4);
      $rand_final = $rand_alphabet.' '.$rand_number;

      header('Content-Type: image/png');

      // Create the image
      $im = imagecreatetruecolor(170, 30);

      // Create some colors
      $white = imagecolorallocate($im, 255, 255, 255);
      $grey = imagecolorallocate($im, 128, 128, 128);
      $black = imagecolorallocate($im, 0, 0, 0);
      imagefilledrectangle($im, 0, 0, 399, 29, $white);

      // The text to draw
      $text = $rand_final;
      // Replace path by your own font path
      $font = 'font.ttf';

      // Add some shadow to the text
      imagettftext($im, 20, 0, 11, 21, $grey, $font, $text);

      // Add the text
      imagettftext($im, 20, 0, 10, 20, $black, $font, $text);

      // Using imagepng() results in clearer text compared with imagejpeg()

      ob_start();
      imagepng($im);
      imagedestroy($im);
      $image_data = ob_get_contents();
      ob_get_clean();
      $dataUri = "data:image/png;base64," . base64_encode($image_data);

      $response['status'] = 1;
      $response['message']['captcha_url'] = $dataUri;
      $response['message']['captcha_hash'] = md5($rand_final);
      // $response['message']['captcha_real'] = $rand_final;
      return $response;
    }

    public function validateCaptcha(Request $r, $hash_captcha)
    {
      $response = [];
      $input_user = $r->input('input_user');

      if (md5($input_user) == $hash_captcha) {
        $response['status'] = 1;
        $response['message'] = 'Right captcha.';
        return response()->json($response);
      }

      $response['status'] = 0;
      $response['message'] = 'Wrong captcha.';
      return response()->json($response);
    }
}
