<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use Illuminate\Support\Facades\Validator;

class UserController extends Controller
{
    public function update(Request $r, $id)
    {
      $response = [];
      $name = $r->input('name');
      $username = $r->input('username');
      $email = $r->input('email');
      $password = $r->input('password');
      $date_birth = $r->input('date_birth');
      $phone_number = $r->input('phone_number');
      $photo = $r->file('photo');

      $validator = Validator::make($r->all(),[
        'name'=>'required',
        'username'=>'required|unique:users,username,'.$id,
        'email'=>'required|email|unique:users,email,'.$id,
        'date_birth'=>'required',
        'phone_number'=>'required',
        'photo'=>'image',
      ]);

      if ($validator->fails()) {
        $response['status'] = 0;
        $response['message']['validation_error'] = $validator->errors()->all();
        return response()->json($response);
      }

      $user = User::find($id);
      $user->name = $name;
      $user->username = $username;
      $user->email = $email;
      if ($password != "") {
        $user->password = bcrypt($password);
      }
      $user->date_birth = $date_birth;
      $user->phone_number = $phone_number;
      if ($photo) {
        $generate_name = round(microtime(true)).'.'.$photo->getClientOriginalExtension();
        $photo->move('img', $generate_name);
        $user->profile_picture = $generate_name;
      }
      $user->save();

      $response['status'] = 1;
      $response['message'] = 'Update profile success.';

      return response()->json($response);
    }

    public function show($id)
    {
      $response = [];

      $user = User::find($id);

      if (count($user) > 0) {
        $response['status'] = 1;
        $response['message']['profile'] = $user;

        return response()->json($response);
      }

      $response['status'] = 0;
      $response['message'] = 'User not found.';

      return response()->json($response);
    }
}
