<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use Validator;
use App\User;

class AuthController extends Controller
{
  public function authenticate(Request $r)
  {
    $response = [];
    $username = $r->input('username');
    $password = $r->input('password');

    if (Auth::attempt(['username'=>$username,'password'=>$password],true)) {
      if (Auth::viaRemember()) {
        $response['status'] = 1;
        $response['message']['user_id'] = Auth::user()->id;
        return response()->json($response);
      }

      $response['status'] = 1;
      $response['message']['user_id'] = Auth::user()->id;
      return response()->json($response);
    }

    $response['status'] = 0;
    $response['message'] = 'Authentication failed.';
    return response()->json($response);
  }

  public function register(Request $r)
  {
    $response = [];
    $name = $r->input('name');
    $username = $r->input('username');
    $email = $r->input('email');
    $password = $r->input('password');
    $date_birth = $r->input('date_birth');
    $phone_number = $r->input('phone_number');
    $photo = $r->file('photo');

    $validator = Validator::make($r->all(),[
      'name'=>'required',
      'username'=>'required|unique:users,username',
      'email'=>'required|email|unique:users,email',
      'password'=>'required',
      'date_birth'=>'required',
      'phone_number'=>'required',
      'photo'=>'required|image',
    ]);

    if ($validator->fails()) {
      $response['status'] = 0;
      $response['message']['validation_error'] = $validator->errors()->all();
      return response()->json($response);
    }

    $generate_name = round(microtime(true)).'.'.$photo->getClientOriginalExtension();
    $photo->move('img', $generate_name);

    $user = new User;
    $user->name = $name;
    $user->username = $username;
    $user->email = $email;
    $user->password = bcrypt($password);
    $user->date_birth = $date_birth;
    $user->phone_number = $phone_number;
    $user->profile_picture = $generate_name;
    $user->save();

    $response['status'] = 1;
    $response['message']['user_id'] = $user->id;

    return response()->json($response);
  }
}
