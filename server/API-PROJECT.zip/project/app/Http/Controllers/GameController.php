<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\EndlessRunning;
use App\Tetris;
use Illuminate\Support\Facades\Validator;

class GameController extends Controller
{
    public function getEndlessRunningLeaderBoard()
    {
      $response = [];
      $leaderboard = EndlessRunning::join('users','endless_runnings.user_id','=','users.id')
                                    ->select('users.name','endless_runnings.score')
                                    ->take(10)
                                    ->orderBy('endless_runnings.score','desc')
                                    ->get();

      if (count($leaderboard) > 0) {
        $response['status'] = 1;
        $response['message']['leaderboard'] = $leaderboard;

        return response()->json($response);
      }

      $response['status'] = 0;
      $response['message'] = 'Data not found.';

      return response()->json($response);
    }

    public function endlessRunningSaveScore(Request $r)
    {
      $response = [];
      $user_id = $r->input('user_id');
      $score = $r->input('score');
      $user = User::find($user_id);

      if (count($user) == 0) {
        $response['status'] = 0;
        $response['message'] = 'User not found.';

        return response()->json($response);
      }

      $validator = Validator::make($r->all(),[
        'score'=>'required',
      ]);

      if ($validator->fails()) {
        $response['status'] = 0;
        $response['message']['validation_error'] = $validator->errors()->all();

        return response()->json($response);
      }

      $new_score = new EndlessRunning;
      $new_score->score = $score;
      $new_score->user_id = $user_id;
      $new_score->save();

      $response['status'] = 1;
      $response['message'] = 'Score sent successfully.';

      return response()->json($response);
    }

    public function getTetrisLeaderBoard()
    {
      $response = [];
      $leaderboard = Tetris::join('users','tetris.user_id','=','users.id')
                            ->select('users.name','tetris.score')
                            ->take(10)
                            ->orderBy('tetris.score','desc')
                            ->get();

      if (count($leaderboard) > 0) {
        $response['status'] = 1;
        $response['message']['leaderboard'] = $leaderboard;

        return response()->json($response);
      }

      $response['status'] = 0;
      $response['message'] = 'Data not found.';

      return response()->json($response);
    }

    public function tetrisSaveScore(Request $r)
    {
      $response = [];
      $user_id = $r->input('user_id');
      $score = $r->input('score');
      $user = User::find($user_id);

      if (count($user) == 0) {
        $response['status'] = 0;
        $response['message'] = 'User not found.';

        return response()->json($response);
      }

      $validator = Validator::make($r->all(),[
        'score'=>'required',
      ]);

      if ($validator->fails()) {
        $response['status'] = 0;
        $response['message']['validation_error'] = $validator->errors()->all();

        return response()->json($response);
      }

      $new_score = new Tetris;
      $new_score->score = $score;
      $new_score->user_id = $user_id;
      $new_score->save();

      $response['status'] = 1;
      $response['message'] = 'Score sent successfully.';

      return response()->json($response);
    }
}
