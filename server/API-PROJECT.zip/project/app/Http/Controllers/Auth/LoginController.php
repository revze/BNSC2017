<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Auth;
use Illuminate\Http\Request;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = '/home';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }

    public function authenticate(Request $r)
    {
      $response = [];
      $username = $r->input('username');
      $password = $r->input('password');

      if (Auth::attempt(['username'=>$username,'password'=>$password],true)) {
        if (Auth::viaRemember()) {
          $response['status'] = 1;
          $response['message']['user_id'] = Auth::user()->id;
          return response()->json($response);
        }

        $response['status'] = 1;
        $response['message']['user_id'] = Auth::user()->id;
        return response()->json($response);
      }

      $response['status'] = 0;
      $response['message'] = 'Authentication failed.';
      return response()->json($response);
    }
}
