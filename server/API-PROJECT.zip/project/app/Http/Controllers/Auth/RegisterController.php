<?php

namespace App\Http\Controllers\Auth;

use App\User;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;
use Auth;
use Illuminate\Http\Request;

class RegisterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    use RegistersUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    protected $redirectTo = '/home';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:6|confirmed',
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return \App\User
     */
    protected function create(array $data)
    {
        return User::create([
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => bcrypt($data['password']),
        ]);
    }

    public function register(Request $r)
    {
      $response = [];
      $name = $r->input('name');
      $username = $r->input('username');
      $email = $r->input('email');
      $password = $r->input('password');
      $date_birth = $r->input('date_birth');
      $phone_number = $r->input('phone_number');
      $photo = $r->file('photo');

      $validator = Validator::make($r->all(),[
        'name'=>'required',
        'username'=>'required|unique:users,username',
        'email'=>'required|email|unique:users,email',
        'password'=>'required',
        'date_birth'=>'required',
        'phone_number'=>'required',
        'photo'=>'required|image',
      ]);

      if ($validator->fails()) {
        $response['status'] = 0;
        $response['message']['validation_error'] = $validator->errors()->all();
        return response()->json($response);
      }

      $generate_name = round(microtime(true)).'.'.$photo->getClientOriginalExtension();
      $photo->move('img', $generate_name);

      $user = new User;
      $user->name = $name;
      $user->username = $username;
      $user->email = $email;
      $user->password = bcrypt($password);
      $user->date_birth = $date_birth;
      $user->phone_number = $phone_number;
      $user->profile_picture = $generate_name;
      $user->save();

      $response['status'] = 1;
      $response['message']['user_id'] = $user->id;

      return response()->json($response);
    }
}
