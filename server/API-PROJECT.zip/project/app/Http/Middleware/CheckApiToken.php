<?php

namespace App\Http\Middleware;

use Closure;
use App\ApiToken;

class CheckApiToken
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
      $response = [];

      $headers = apache_request_headers();

      if (!isset($headers['api_token'])) {
          $response['success'] = 0;
          $response['message'] = "Invalid API Key.";
          return response()->json($response);
      }

      if ($headers['api_token'] != '') {
        $api_token = ApiToken::where('token',$headers['api_token'])->first();
        if (count($api_token) == 0) {
          $response['success'] = 0;
          $response['message'] = "Invalid API Key.";
          return response()->json($response);
        }
      }

      return $next($request);
    }
}
