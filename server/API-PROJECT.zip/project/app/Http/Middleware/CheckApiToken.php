<?php

namespace App\Http\Middleware;

use Closure;
use App\ApiToken;

class CheckApiToken
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
      $response = [];

      $headers = apache_request_headers();
      $api_header = '';

      if (!isset($headers['api_token'])) {
        $api_header = $headers['Api_token'];
      }
      else {
        $api_header = $headers['api_token'];
      }

        if (!isset($api_header)) {
          $response['success'] = 0;
          $response['message'] = 'API Key is not set.';
          return response()->json($response);
        }

        $api_token = ApiToken::where('token',$api_header)->first();
        if (count($api_token) == 0) {
          $response['success'] = 0;
          $response['message'] = "Invalid API Key.";
          return response()->json($response);
        }

        return $next($request);
    }
}
