<?php

namespace App\Http\Middleware;

use Closure;
use App\ApiToken;

class CheckApiToken
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
      $response = [];

      //For live server use Api_token header for get method

      $headers = apache_request_headers();
      // return response()->json($headers);

      if ($request->method() == 'GET') {
        //Only for get method
        if (!isset($headers['api_token'])) {
          $response['success'] = 0;
          $response['message'] = 'API Key is not set.';
          return response()->json($response);
        }

        $api_token = ApiToken::where('token',$headers['api_token'])->first();
        if (count($api_token) == 0) {
          $response['success'] = 0;
          $response['message'] = "Invalid API Key.";
          return response()->json($response);
        }

        return $next($request);
      }

      if ($request->method() == 'POST') {
        //Only for post method
        if (!isset($headers['api_token'])) {
          $response['success'] = 0;
          $response['message'] = 'API Key is not set.';
          return response()->json($response);
        }

        $api_token = ApiToken::where('token',$headers['api_token'])->first();
        if (count($api_token) == 0) {
          $response['success'] = 0;
          $response['message'] = "Invalid API Key.";
          return response()->json($response);
        }

        return $next($request);
      }

      // return response()->json($headers['Api_token']);
      // foreach ($headers as $header => $value) {
      //   if ($header == 'api_token') {
      //     $response['api_key'] = $value;
      //     return response()->json($response);
      //     // echo $header.': '.$value.'<br>';
      //   //   $api_key = $value;
      //   //   // break;
      //   }
      //   // else {
      //   //   $api_key = $value;
      //   // }
      // }

      // if (isset($response['api_key'])) {
      //   return response()->json('tes');
      // }
      // else {
      //   return response()->json($response['api_key']);
      // }
      // echo $key;


      // if ($key == '') {
      //   $response['success'] = 0;
      //   $response['key'] = $key;
      //   $response['message'] = "API Key not set.";
      //   // $response['message'] = "Invalid API Key.";
      //   return response()->json($response);
      // }
      //
      // $api_token = ApiToken::where('token',$key)->first();
      // if (count($api_token) == 0) {
      //   $response['success'] = 0;
      //   $response['message'] = "Invalid API Key.";
      //   return response()->json($response);
      // }
      //
      // return $next($request);

      // return $response['tes_header'];
      // $response['tes'] = $request->header('api_token');
      // return response()->json($response);

      // if(!isset($_SERVER['HTTP_X_HARDIK'])){
      //       return response()->json(array('error'=>'Please set custom header'));
      //   }
      //
      //   if($_SERVER['HTTP_X_HARDIK'] != '123456'){
      //       return response()->json(array('error'=>'wrong custom header'));
      //   }
      // if(!isset($_SERVER['api_token'])){
      //   $response['success'] = 0;
      //   $response['message'] = "API Key not set.";
      //   return response()->json($response);
      // }
      //
      // if ($_SERVER['api_token']) {
      //   $api_token = ApiToken::where('token',$_SERVER['api_token'])->first();
      //   if (count($api_token) == 0) {
      //     $response['success'] = 0;
      //     $response['message'] = "Invalid API Key.";
      //     return response()->json($response);
      //   }
      //
      // }
      // return $next($request);

      // if($_SERVER['api_token'] != '123456'){
      //   return response()->json(array('error'=>'wrong custom header'));
      // }

      // return $next($request);

      // $headers = apache_request_headers();

      // if (!isset($headers['api_token'])) {
      //   $response['success'] = 0;
      //   $response['message'] = "API key not set.";
      //   return response()->json($response);
      // }
      //
      // if (isset($headers['api_token'])) {
      //   $api_token = ApiToken::where('token',$headers['api_token'])->first();
      //   if (count($api_token) == 0) {
      //     $response['success'] = 0;
      //     $response['message'] = "Invalid API Key.";
      //     return response()->json($response);
      //   }
      //
      //   else {
      //     return $next($request);
      //   }
      // }
      // else {
      // }

      // if (!isset($headers['api_token'])) {
      //     $response['success'] = 0;
      //     $response['message'] = "Invalid API Key 1.";
      //     return response()->json($response);
      // }
      //
      // if ($headers['api_token'] != '') {
      //   $api_token = ApiToken::where('token',$headers['api_token'])->first();
      //   if (count($api_token) == 0) {
      //     $response['success'] = 0;
      //     $response['message'] = "Invalid API Key tes.";
      //     return response()->json($response);
      //   }
      // }

      // return $next($request);
    }
}
