<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::group(['middleware'=>'checkapitoken'], function() {
  Route::post('login', 'Auth\LoginController@authenticate'); //Status: tested
  Route::post('register', 'Auth\RegisterController@register'); //Status: tested
  Route::post('user/update/{id}', 'UserController@update'); //Status: tested
  Route::get('user/{id}/show', 'UserController@show'); //Status: tested
  Route::get('endless-running/leaderboard','GameController@getEndlessRunningLeaderBoard'); //Status: tested
  Route::post('endless-running/save/score','GameController@endlessRunningSaveScore'); //Status: tested
  Route::get('tetris/leaderboard','GameController@getTetrisLeaderBoard'); //Status: tested
  Route::post('tetris/save/score','GameController@tetrisSaveScore'); //Status: tested
  Route::get('captcha/generate','CaptchaController@generateCaptcha'); //Status: tested
  Route::post('captcha/validate/{hash_captcha}','CaptchaController@validateCaptcha'); //Status: tested
});
