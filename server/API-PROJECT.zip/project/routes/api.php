<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::group(['middleware'=>'checkapitoken'], function() {
  Route::post('login', 'Auth\LoginController@authenticate');
  Route::post('register', 'Auth\RegisterController@register');
  Route::post('user/update/{id}', 'UserController@update');
  Route::get('user/{id}/show', 'UserController@show');
  Route::get('endless-running/leaderboard','GameController@getEndlessRunningLeaderBoard');
  Route::post('endless-running/save/score','GameController@endlessRunningSaveScore');
  Route::get('tetris/leaderboard','GameController@getTetrisLeaderBoard');
  Route::post('tetris/save/score','GameController@tetrisSaveScore');
  Route::get('captcha/generate','CaptchaController@generateCaptcha');
  Route::post('captcha/validate/{hash_captcha}','CaptchaController@validateCaptcha');
});
